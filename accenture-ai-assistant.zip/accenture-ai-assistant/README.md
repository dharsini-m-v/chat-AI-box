# Accenture AI Assistant — Chat Widget

A floating, purple-themed AI assistant widget for an Accenture-styled website, plus a
small secure backend that proxies chat requests to an LLM. Built to be dropped into
**any** existing site (plain HTML, React, Angular, etc.) since the widget itself is
framework-agnostic vanilla JS/CSS.

```
accenture-ai-assistant/
├── frontend/
│   ├── chat-widget.js      # Widget logic (state, rendering, API calls, fallback)
│   ├── chat-widget.css     # Purple enterprise theme, animations, responsive rules
│   ├── index.html          # Demo host page with the widget embedded
│   └── .env.example
├── backend/
│   ├── server.js           # Express API: POST /api/chat
│   ├── package.json
│   └── .env.example
└── README.md
```

## How it works

```
Browser (chat-widget.js)
        │  POST /api/chat  { message }
        ▼
Backend (Express, server.js)
        │  reads MODEL_API_KEY from env (never sent to the browser)
        ▼
LLM Provider API (Anthropic Messages API by default)
        │
        ▼
Backend responds  { reply }
        │
        ▼
Widget renders the reply, with markdown-lite formatting
```

If the backend is unreachable, times out, or returns an error, the widget **does not
crash** — it shows a small error banner and answers from a built-in set of predefined
responses covering common questions (company overview, applying, tech stack, fresher
eligibility, interview prep, etc.), defined in `FALLBACK_KB` inside `chat-widget.js`.

## Frontend integration

Drop these two files into any site and initialize the widget:

```html
<link rel="stylesheet" href="chat-widget.css" />
<script src="chat-widget.js"></script>
<script>
  AccentureAIWidget.init({ apiUrl: "https://your-backend.example.com/api/chat" });
</script>
```

All widget styles are scoped under `#aaa-root`, so it won't leak into or be affected by
the host page's CSS. No API keys ever appear in this file — it only ever talks to your
own backend's `/api/chat` endpoint.

## Local setup

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
# edit .env and set MODEL_API_KEY + ALLOWED_ORIGIN
npm start
```

Backend runs at `http://localhost:5000` by default. Health check: `GET /api/health`.

### 2. Frontend (static demo)

```bash
cd frontend
cp .env.example .env
# any static file server works, e.g.:
npx serve .
```

Open the served URL — the demo page has the floating purple chat icon bottom-right.

## Environment variables

| File | Variable | Purpose |
|---|---|---|
| `backend/.env` | `PORT` | Port the API listens on (default 5000) |
| `backend/.env` | `ALLOWED_ORIGIN` | CORS origin allowed to call the API (your deployed frontend URL) |
| `backend/.env` | `MODEL_API_KEY` | Your LLM provider's API key — **only set on the server**, never in frontend code |
| `frontend/.env` | `AAA_API_URL` | The backend's public `/api/chat` URL, used when initializing the widget |

## Production build & deployment

**Backend** (any Node host — Render, Railway, Fly.io, EC2):

```bash
cd backend
npm install --production
# set PORT, ALLOWED_ORIGIN, MODEL_API_KEY in the host's environment settings
npm start
```

**Frontend**: `chat-widget.js` / `chat-widget.css` are static assets — host them via any
CDN, or bundle them into your existing app's build (Webpack/Vite copy step). Point
`apiUrl` at your deployed backend's URL, ideally injected via a build-time environment
variable rather than hardcoded.

## Security notes

- The LLM API key lives only in `backend/.env` (server-side), never in any file served
  to the browser.
- Requests are rate-limited (20/minute/IP) via `express-rate-limit`.
- Message length is capped (1000 chars) both client- and server-side.
- All rendered chat content is HTML-escaped before the lightweight markdown formatter
  runs, preventing XSS from AI or fallback text.
- CORS is restricted to `ALLOWED_ORIGIN`.
- Backend error details are never forwarded to the client — only a generic message.

## Pre-flight checklist

- [ ] `npm start` in `backend/` runs with no console errors
- [ ] Widget opens/closes with animation, Escape key closes it
- [ ] Suggested question chips and quick-action buttons send messages
- [ ] Typing indicator shows while waiting for a reply
- [ ] Copy / Regenerate buttons work on AI messages
- [ ] Stopping the backend triggers the fallback banner + predefined answer (no crash)
- [ ] Chat persists in `localStorage` after closing/reopening the tab
- [ ] "Clear conversation" asks for confirmation before clearing
- [ ] Mobile viewport (≤480px) shows a full-width panel
- [ ] No API keys appear anywhere in `frontend/` files or browser dev tools

## Note

This is a themed demo/portfolio project ("Accenture-styled") and is not an official
Accenture product.

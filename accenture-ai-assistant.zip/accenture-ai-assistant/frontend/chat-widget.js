/**
 * Accenture AI Assistant — Floating Chat Widget
 * Vanilla JS, framework-agnostic. Drop into any site:
 *
 *   <link rel="stylesheet" href="chat-widget.css">
 *   <script src="chat-widget.js"></script>
 *   <script>
 *     AccentureAIWidget.init({ apiUrl: "https://your-backend.example.com/api/chat" });
 *   </script>
 *
 * No API keys live in this file. All AI calls go through your backend's
 * POST /api/chat endpoint. If that endpoint is unreachable, the widget
 * falls back to a small set of predefined answers so it never breaks.
 */
(function () {
  "use strict";

  const STORAGE_KEY = "aaa_chat_history_v1";
  const MAX_MESSAGE_LEN = 1000;
  const REQUEST_TIMEOUT_MS = 15000;

  const SUGGESTED_QUESTIONS = [
    "What does Accenture do?",
    "How can I apply for a job?",
    "What technologies does Accenture use?",
    "What are the eligibility criteria for freshers?",
    "What career opportunities are available?",
    "Tell me about Accenture's services",
    "How can I prepare for an Accenture interview?",
    "Tell me about AI and GenAI at Accenture",
  ];

  const QUICK_ACTIONS = [
    { label: "\uD83D\uDCBC Careers", question: "What career opportunities are available at Accenture?" },
    { label: "\uD83E\uDD16 AI & Technology", question: "Tell me about AI and GenAI at Accenture" },
    { label: "\uD83D\uDCC4 Resume", question: "How should I prepare my resume for Accenture?" },
    { label: "\uD83C\uDFAF Interview Prep", question: "How can I prepare for an Accenture interview?" },
    { label: "\uD83C\uDFE2 About Accenture", question: "What does Accenture do?" },
  ];

  // Predefined fallback answers used when the backend is unreachable.
  const FALLBACK_KB = [
    {
      match: ["what does accenture do", "about accenture", "company overview"],
      reply:
        "Accenture is a global professional services company providing strategy, consulting, technology, operations, and digital transformation services across industries such as banking, healthcare, retail, and communications. It helps clients modernize their technology, adopt AI and cloud, and improve business performance.",
    },
    {
      match: ["apply", "how can i apply", "application process"],
      reply:
        "You can apply through Accenture's official careers site. Typical steps are:\n1. Create a profile and submit your resume for a matching role.\n2. Complete an online aptitude/coding assessment.\n3. Attend technical and HR interview rounds.\n4. Receive an offer and complete onboarding formalities.\n\nTip: Tailor your resume to the specific role and keep your project descriptions concise and outcome-focused.",
      followups: ["How can I prepare for an Accenture interview?", "What skills do I need as a fresher?"],
    },
    {
      match: ["technolog", "tech stack", "genai", "generative ai", "ai at accenture"],
      reply:
        "Accenture works across a wide technology landscape, including:\n- Cloud platforms (AWS, Azure, GCP)\n- Data & Analytics\n- Generative AI and applied AI solutions\n- Cybersecurity\n- Software engineering & automation\n- Industry-specific digital platforms\n\nGenAI in particular is a major focus area, used for things like intelligent automation, code assistance, and customer experience.",
      followups: ["What GenAI skills should I learn?", "Can you suggest AI projects for my resume?"],
    },
    {
      match: ["fresher", "eligibility", "new grad", "campus"],
      reply:
        "For fresher roles, Accenture typically looks for:\n- A completed or final-year degree (any stream, often with a minimum aggregate)\n- Strong fundamentals in programming, logical reasoning, and communication\n- No active/pending academic backlogs at the time of joining\n\nExact eligibility criteria vary by role and hiring drive, so always check the specific job posting for current requirements.",
    },
    {
      match: ["career opportunit", "roles available", "job openings"],
      reply:
        "Accenture hires across many tracks: Software Engineering, Cloud, Data & AI, Cybersecurity, Business & Strategy Consulting, and industry-specific delivery roles \u2014 for freshers, experienced professionals, and interns.",
      followups: ["How can I apply for a job?", "What skills are required for an AI role?"],
    },
    {
      match: ["services", "consulting", "what does accenture offer"],
      reply:
        "Accenture's core service lines are Strategy & Consulting, Technology, Operations, and Industry X (engineering & manufacturing services) \u2014 all increasingly powered by data, cloud, and AI.",
    },
    {
      match: ["interview", "prepare for", "hr questions", "technical interview"],
      reply:
        "A solid Accenture interview prep plan covers four areas:\n1. Aptitude & reasoning \u2014 quantitative, logical, and verbal practice.\n2. Technical fundamentals \u2014 programming, OOP, DBMS, SQL, OS basics.\n3. Problem solving \u2014 practice coding problems and explain your approach out loud.\n4. HR & behavioral \u2014 be ready for \"Tell me about yourself\", \"Why Accenture?\", and questions about your projects.\n\nTip: know every project and technology on your resume in depth \u2014 it's the most common source of follow-up questions.",
      followups: ["What are common HR interview questions?", "How do I explain my projects well?"],
    },
    {
      match: ["skills required", "skills needed", "ai role", "ml role"],
      reply:
        "For AI/ML-adjacent roles, useful skills include Python, SQL, core ML concepts, familiarity with an LLM framework (like LangChain), REST API basics, and at least one solid end-to-end project you can explain clearly.",
      followups: ["How should I prepare for an AI interview?", "What GenAI technologies should I learn?"],
    },
  ];

  const DEFAULT_FALLBACK =
    "I'm having trouble connecting to the AI service right now. Please try again in a moment. In the meantime, you can tap one of the suggestions below and I'll do my best with what I already know.";

  function findFallback(question) {
    const q = question.toLowerCase();
    for (const entry of FALLBACK_KB) {
      if (entry.match.some((m) => q.includes(m))) return entry;
    }
    return null;
  }

  // ---- tiny, safe markdown-ish renderer (escapes HTML first) ----
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function renderMarkdownLite(raw) {
    const escaped = escapeHtml(raw);
    const lines = escaped.split("\n");
    let html = "";
    let inList = null; // 'ul' | 'ol'

    const closeList = () => {
      if (inList) {
        html += `</${inList}>`;
        inList = null;
      }
    };

    for (let line of lines) {
      const bulletMatch = line.match(/^\s*[-•]\s+(.*)/);
      const numberMatch = line.match(/^\s*\d+[.)]\s+(.*)/);
      if (bulletMatch) {
        if (inList !== "ul") { closeList(); html += "<ul>"; inList = "ul"; }
        html += `<li>${inlineFormat(bulletMatch[1])}</li>`;
      } else if (numberMatch) {
        if (inList !== "ol") { closeList(); html += "<ol>"; inList = "ol"; }
        html += `<li>${inlineFormat(numberMatch[1])}</li>`;
      } else if (line.trim() === "") {
        closeList();
      } else {
        closeList();
        html += `<p>${inlineFormat(line)}</p>`;
      }
    }
    closeList();
    return html;
  }

  function inlineFormat(text) {
    let out = text;
    out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
    out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/(https?:\/\/[^\s)]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
    return out;
  }

  function timeNow() {
    return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function uid() {
    return Math.random().toString(36).slice(2, 10);
  }

  // ---------------------------------------------------------------------

  class AccentureAIWidget {
    constructor(options) {
      this.apiUrl = options.apiUrl || "/api/chat";
      this.container = null;
      this.messages = [];
      this.isOpen = false;
      this.isMinimized = false;
      this.isSending = false;
      this._loadHistory();
      this._buildDom();
      this._bindEvents();
      this._render();
    }

    _loadHistory() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        this.messages = raw ? JSON.parse(raw) : [];
      } catch (e) {
        this.messages = [];
      }
    }

    _saveHistory() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.messages.slice(-100)));
      } catch (e) {
        /* storage unavailable — degrade silently, chat still works in-session */
      }
    }

    _buildDom() {
      const root = document.createElement("div");
      root.id = "aaa-root";
      root.innerHTML = `
        <button class="aaa-launcher" id="aaa-launcher" aria-label="Open Accenture AI Assistant" aria-expanded="false">
          ${ICONS.chat}
          ${ICONS.close}
          <span class="aaa-dot"></span>
        </button>
        <div class="aaa-tooltip">Ask Accenture AI</div>

        <section class="aaa-panel" id="aaa-panel" role="dialog" aria-modal="false" aria-label="Accenture AI Assistant chat">
          <header class="aaa-header">
            <div class="aaa-avatar">${ICONS.bot}</div>
            <div class="aaa-header-text">
              <div class="aaa-header-title">Accenture AI Assistant</div>
              <div class="aaa-header-sub">Your intelligent workplace &amp; career companion</div>
              <div class="aaa-status"><span class="aaa-status-dot"></span> Online</div>
            </div>
            <div class="aaa-header-actions">
              <button id="aaa-minimize" aria-label="Minimize chat" title="Minimize">${ICONS.minimize}</button>
              <button id="aaa-close" aria-label="Close chat" title="Close">${ICONS.x}</button>
            </div>
          </header>

          <div class="aaa-messages" id="aaa-messages" role="log" aria-live="polite"></div>

          <div id="aaa-error-slot"></div>

          <div class="aaa-input-area">
            <div class="aaa-input-row">
              <textarea id="aaa-input" rows="1" maxlength="${MAX_MESSAGE_LEN}"
                placeholder="Ask me anything..." aria-label="Type your message"></textarea>
              <button class="aaa-send-btn" id="aaa-send" disabled aria-label="Send message">${ICONS.send}</button>
            </div>
            <div class="aaa-input-footer">
              <span class="aaa-char-count" id="aaa-char-count">0/${MAX_MESSAGE_LEN}</span>
              <button class="aaa-clear-link" id="aaa-clear-trigger">${ICONS.trash} Clear conversation</button>
            </div>
          </div>
        </section>
      `;
      document.body.appendChild(root);
      this.container = root;
    }

    _bindEvents() {
      const $ = (sel) => this.container.querySelector(sel);

      $("#aaa-launcher").addEventListener("click", () => this.toggleOpen());
      $("#aaa-close").addEventListener("click", () => this.setOpen(false));
      $("#aaa-minimize").addEventListener("click", () => this.setOpen(false));

      const input = $("#aaa-input");
      const sendBtn = $("#aaa-send");
      const charCount = $("#aaa-char-count");

      input.addEventListener("input", () => {
        sendBtn.disabled = input.value.trim().length === 0 || this.isSending;
        charCount.textContent = `${input.value.length}/${MAX_MESSAGE_LEN}`;
        input.style.height = "auto";
        input.style.height = Math.min(input.scrollHeight, 90) + "px";
      });

      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          this._handleSend();
        }
      });

      sendBtn.addEventListener("click", () => this._handleSend());

      $("#aaa-clear-trigger").addEventListener("click", () => this._showClearConfirm());

      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && this.isOpen) this.setOpen(false);
      });
    }

    toggleOpen() { this.setOpen(!this.isOpen); }

    setOpen(open) {
      this.isOpen = open;
      const panel = this.container.querySelector("#aaa-panel");
      const launcher = this.container.querySelector("#aaa-launcher");
      panel.classList.toggle("aaa-visible", open);
      launcher.classList.toggle("aaa-open", open);
      launcher.setAttribute("aria-expanded", String(open));
      if (open) {
        if (this.messages.length === 0) this._renderWelcome();
        this._scrollToBottom();
        setTimeout(() => this.container.querySelector("#aaa-input").focus(), 200);
      }
    }

    async _handleSend(presetText) {
      const input = this.container.querySelector("#aaa-input");
      const text = (presetText !== undefined ? presetText : input.value).trim();
      if (!text || this.isSending) return;

      this._clearWelcome();
      this._pushMessage({ id: uid(), role: "user", text, time: timeNow() });

      input.value = "";
      input.style.height = "auto";
      this.container.querySelector("#aaa-send").disabled = true;
      this.container.querySelector("#aaa-char-count").textContent = `0/${MAX_MESSAGE_LEN}`;

      this._setSending(true);
      this._showTyping(true);
      this._clearError();

      try {
        const reply = await this._fetchReply(text);
        this._showTyping(false);
        this._pushMessage({
          id: uid(),
          role: "ai",
          text: reply.text,
          time: timeNow(),
          followups: reply.followups || [],
        });
      } catch (err) {
        this._showTyping(false);
        const fb = findFallback(text);
        this._pushMessage({
          id: uid(),
          role: "ai",
          text: fb ? fb.reply : DEFAULT_FALLBACK,
          time: timeNow(),
          followups: fb && fb.followups ? fb.followups : [],
          isFallback: true,
        });
        this._showError();
      } finally {
        this._setSending(false);
      }
    }

    async _fetchReply(message) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
      try {
        const res = await fetch(this.apiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message }),
          signal: controller.signal,
        });
        if (!res.ok) throw new Error("Backend error: " + res.status);
        const data = await res.json();
        if (!data || typeof data.reply !== "string") throw new Error("Malformed response");
        return { text: data.reply, followups: data.followups || [] };
      } finally {
        clearTimeout(timeout);
      }
    }

    _setSending(val) {
      this.isSending = val;
      const sendBtn = this.container.querySelector("#aaa-send");
      const input = this.container.querySelector("#aaa-input");
      sendBtn.disabled = val || input.value.trim().length === 0;
    }

    _pushMessage(msg) {
      this.messages.push(msg);
      this._saveHistory();
      this._appendMessageDom(msg);
      this._scrollToBottom();
    }

    _appendMessageDom(msg) {
      const list = this.container.querySelector("#aaa-messages");
      const row = document.createElement("div");
      row.className = `aaa-row aaa-${msg.role}`;
      row.dataset.id = msg.id;

      const bubbleHtml =
        msg.role === "ai"
          ? `<div class="aaa-bubble-icon">${ICONS.bot}</div>
             <div class="aaa-bubble-wrap">
               <div class="aaa-bubble">${renderMarkdownLite(msg.text)}</div>
               <div class="aaa-timestamp">${msg.time}</div>
               <div class="aaa-msg-actions">
                 <button class="aaa-copy-btn">${ICONS.copy} Copy</button>
                 <button class="aaa-regen-btn">${ICONS.refresh} Regenerate</button>
               </div>
               ${this._followupsHtml(msg.followups)}
             </div>`
          : `<div class="aaa-bubble-wrap">
               <div class="aaa-bubble">${renderMarkdownLite(msg.text)}</div>
               <div class="aaa-timestamp">${msg.time}</div>
             </div>`;

      row.innerHTML = bubbleHtml;
      list.appendChild(row);

      if (msg.role === "ai") {
        row.querySelector(".aaa-copy-btn").addEventListener("click", () => {
          navigator.clipboard?.writeText(msg.text).catch(() => {});
        });
        row.querySelector(".aaa-regen-btn").addEventListener("click", () => this._regenerate(msg.id));
        row.querySelectorAll(".aaa-followup-chip").forEach((chip) => {
          chip.addEventListener("click", () => this._handleSend(chip.textContent.trim()));
        });
      }
    }

    _followupsHtml(followups) {
      if (!followups || followups.length === 0) return "";
      const chips = followups
        .slice(0, 3)
        .map((f) => `<button class="aaa-chip aaa-followup-chip">${escapeHtml(f)}</button>`)
        .join("");
      return `<div class="aaa-followup-label">You may also want to ask:</div><div class="aaa-chips">${chips}</div>`;
    }

    async _regenerate(messageId) {
      const idx = this.messages.findIndex((m) => m.id === messageId);
      if (idx < 1) return;
      const priorUser = [...this.messages.slice(0, idx)].reverse().find((m) => m.role === "user");
      if (!priorUser) return;

      this._showTyping(true);
      try {
        const reply = await this._fetchReply(priorUser.text);
        this.messages[idx] = { ...this.messages[idx], text: reply.text, followups: reply.followups, time: timeNow() };
      } catch {
        const fb = findFallback(priorUser.text);
        this.messages[idx] = {
          ...this.messages[idx],
          text: fb ? fb.reply : DEFAULT_FALLBACK,
          followups: fb?.followups || [],
          time: timeNow(),
        };
        this._showError();
      }
      this._showTyping(false);
      this._saveHistory();
      this._rerenderAll();
    }

    _rerenderAll() {
      const list = this.container.querySelector("#aaa-messages");
      list.innerHTML = "";
      this.messages.forEach((m) => this._appendMessageDom(m));
      this._scrollToBottom();
    }

    _showTyping(show) {
      let el = this.container.querySelector("#aaa-typing-row");
      const list = this.container.querySelector("#aaa-messages");
      if (show) {
        if (el) return;
        el = document.createElement("div");
        el.id = "aaa-typing-row";
        el.className = "aaa-row aaa-ai";
        el.innerHTML = `
          <div class="aaa-bubble-icon">${ICONS.bot}</div>
          <div class="aaa-typing">Accenture AI is thinking
            <span class="aaa-typing-dots"><span></span><span></span><span></span></span>
          </div>`;
        list.appendChild(el);
        this._scrollToBottom();
      } else if (el) {
        el.remove();
      }
    }

    _showError() {
      const slot = this.container.querySelector("#aaa-error-slot");
      slot.innerHTML = `<div class="aaa-error-banner">I couldn't reach the AI service, so I've given you a best-effort answer above. Please try again shortly.</div>`;
    }

    _clearError() {
      this.container.querySelector("#aaa-error-slot").innerHTML = "";
    }

    _renderWelcome() {
      const list = this.container.querySelector("#aaa-messages");
      const wrap = document.createElement("div");
      wrap.className = "aaa-row aaa-ai";
      wrap.id = "aaa-welcome-row";
      const chips = SUGGESTED_QUESTIONS.map(
        (q) => `<button class="aaa-chip aaa-suggestion-chip">${escapeHtml(q)}</button>`
      ).join("");
      const quickActions = QUICK_ACTIONS.map(
        (qa) => `<button class="aaa-quick-action" data-q="${escapeHtml(qa.question)}">${qa.label}</button>`
      ).join("");
      wrap.innerHTML = `
        <div class="aaa-bubble-icon">${ICONS.bot}</div>
        <div class="aaa-bubble-wrap">
          <div class="aaa-bubble">
            <div class="aaa-welcome-title">Hi! \uD83D\uDC4B I'm Accenture AI Assistant.</div>
            <div>How can I help you today?</div>
            <div class="aaa-quick-actions">${quickActions}</div>
            <div class="aaa-chips">${chips}</div>
          </div>
        </div>`;
      list.appendChild(wrap);

      wrap.querySelectorAll(".aaa-suggestion-chip").forEach((chip) => {
        chip.addEventListener("click", () => this._handleSend(chip.textContent.trim()));
      });
      wrap.querySelectorAll(".aaa-quick-action").forEach((btn) => {
        btn.addEventListener("click", () => this._handleSend(btn.dataset.q));
      });
    }

    _clearWelcome() {
      const el = this.container.querySelector("#aaa-welcome-row");
      if (el) el.remove();
    }

    _showClearConfirm() {
      const panel = this.container.querySelector("#aaa-panel");
      if (panel.querySelector(".aaa-confirm-overlay")) return;
      const overlay = document.createElement("div");
      overlay.className = "aaa-confirm-overlay";
      overlay.innerHTML = `
        <div class="aaa-confirm-box">
          <p>Clear this conversation?</p>
          <div class="aaa-confirm-actions">
            <button class="aaa-confirm-cancel">Cancel</button>
            <button class="aaa-confirm-clear">Clear</button>
          </div>
        </div>`;
      panel.style.position = "relative";
      panel.appendChild(overlay);
      overlay.querySelector(".aaa-confirm-cancel").addEventListener("click", () => overlay.remove());
      overlay.querySelector(".aaa-confirm-clear").addEventListener("click", () => {
        this.messages = [];
        this._saveHistory();
        this._rerenderAll();
        this._renderWelcome();
        overlay.remove();
      });
    }

    _scrollToBottom() {
      const list = this.container.querySelector("#aaa-messages");
      requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
    }

    _render() {
      this._rerenderAll();
      if (this.messages.length === 0) {
        // Welcome renders lazily on first open to match spec.
      }
    }
  }

  const ICONS = {
    chat: `<svg class="aaa-icon-chat" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>`,
    close: `<svg class="aaa-icon-close" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>`,
    bot: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 8V4M9 4h6"/><circle cx="9" cy="14" r="1"/><circle cx="15" cy="14" r="1"/></svg>`,
    minimize: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg>`,
    x: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>`,
    send: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>`,
    copy: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
    refresh: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.5 15"/></svg>`,
    trash: `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg>`,
  };

  window.AccentureAIWidget = {
    init(options) {
      if (window.__aaaInstance) return window.__aaaInstance;
      window.__aaaInstance = new AccentureAIWidget(options || {});
      return window.__aaaInstance;
    },
  };
})();

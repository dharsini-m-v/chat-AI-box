/**
 * Accenture AI Assistant — Backend API
 *
 * Exposes POST /api/chat which forwards the user's message to an LLM
 * (Anthropic Claude by default; swap the callModel() body for OpenAI etc.)
 * The API key NEVER touches the frontend — it only lives in this process's
 * environment variables.
 */
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const app = express();

const PORT = process.env.PORT || 5000;
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "http://localhost:3000";
const MODEL_API_KEY = process.env.MODEL_API_KEY; // Anthropic/OpenAI key, set only via env
const MAX_MESSAGE_LEN = 1000;

app.use(express.json({ limit: "20kb" }));
app.use(
  cors({
    origin: ALLOWED_ORIGIN,
    methods: ["POST", "GET"],
  })
);

// Basic abuse protection
app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests. Please slow down and try again shortly." },
  })
);

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

// ---- very small system-prompt-driven persona for the assistant ----
const SYSTEM_PROMPT = `You are Accenture AI Assistant, a helpful, professional assistant embedded on an
Accenture-themed careers/company website. Answer questions about Accenture's services, technology,
careers, recruitment process, interview preparation, and workplace topics. Keep answers concise,
well-structured (use short paragraphs or bullet points), and friendly but professional. If a question
is unrelated to Accenture, careers, or technology, politely redirect the user back to those topics.
Never claim to have real-time access to specific job postings or personal application status.`;

function sanitizeInput(message) {
  if (typeof message !== "string") return null;
  const trimmed = message.trim();
  if (!trimmed || trimmed.length > MAX_MESSAGE_LEN) return null;
  // Strip control characters; the frontend also escapes on render.
  return trimmed.replace(/[\u0000-\u001F\u007F]/g, "");
}

async function callModel(userMessage) {
  if (!MODEL_API_KEY) {
    throw new Error("MODEL_API_KEY not configured");
  }

  // Example using Anthropic's Messages API. Swap this block for any provider.
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": MODEL_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 500,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }],
    }),
  });

  if (!response.ok) {
    throw new Error(`Model API error: ${response.status}`);
  }

  const data = await response.json();
  const textBlock = (data.content || []).find((b) => b.type === "text");
  if (!textBlock) throw new Error("Empty model response");
  return textBlock.text;
}

app.post("/api/chat", async (req, res) => {
  try {
    const message = sanitizeInput(req.body?.message);
    if (!message) {
      return res.status(400).json({ error: "Invalid message." });
    }

    const reply = await callModel(message);
    return res.json({ reply });
  } catch (err) {
    // Never leak internal error details to the client.
    console.error("[/api/chat] error:", err.message);
    return res.status(503).json({
      error: "AI service temporarily unavailable.",
      reply:
        "I'm having trouble connecting to the AI service right now. Please try again in a moment.",
    });
  }
});

// Fallback 404 for anything else
app.use((_req, res) => res.status(404).json({ error: "Not found" }));

app.listen(PORT, () => {
  console.log(`Accenture AI Assistant backend running on port ${PORT}`);
});
